package assist.cmv.CMV.repository;

import assist.cmv.CMV.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Integer> {



}
